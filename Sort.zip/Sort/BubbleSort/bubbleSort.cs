﻿
namespace BubbleSort;

public class bubbleSort<T> : ISortable.ISortble<T> where T : IComparable<T>
{
    public T[] AscendingSort(T[] values)
    {
        for (int i = 0; i < values.Length - 1; i++)
        {
            for (int j = 0; j < values.Length - i - 1; j++)
            {
                if (values[j].CompareTo(values[j + 1]) > 0) // مقایسه برای صعودی
                {
                    (values[j], values[j + 1]) = (values[j + 1], values[j]); // جا‌به‌جایی
                }
            }
        }
        return values;
    }

    public T[] DescendingSort(T[] values)
    {
        for (int i = 0; i < values.Length - 1; i++)
        {
            for (int j = 0; j < values.Length - i - 1; j++)
            {
                if (values[j].CompareTo(values[j + 1]) < 0) // مقایسه برای نزولی
                {
                    (values[j], values[j + 1]) = (values[j + 1], values[j]); // جا‌به‌جایی
                }
            }
        }
        return values;
    }
}

