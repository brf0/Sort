﻿namespace ISoortable
{
    public class Class1
    {

    }
}
