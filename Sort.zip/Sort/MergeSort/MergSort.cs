﻿
namespace MergeSort;

public class MergSort<T> : ISortable.ISortble<T> where T : IComparable<T>
{
    public T[] AscendingSort(T[] values)
    {
        // اگر آرایه تنها یک یا صفر عنصر دارد، نیازی به مرتب‌سازی نیست.
        if (values.Length <= 1)
            return values;

        // تقسیم آرایه به دو بخش
        int mid = values.Length / 2;
        T[] left = new T[mid];
        T[] right = new T[values.Length - mid];

        Array.Copy(values, 0, left, 0, mid); // کپی عناصر به بخش چپ
        Array.Copy(values, mid, right, 0, values.Length - mid); // کپی عناصر به بخش راست

        // مرتب‌سازی بازگشتی بخش‌های چپ و راست
        left = AscendingSort(left);
        right = AscendingSort(right);

        // ادغام بخش‌های مرتب شده
        return MergeAscending(left, right);
    }

    public T[] DescendingSort(T[] values)
    {
        if (values.Length <= 1)
            return values;

        int mid = values.Length / 2;
        T[] left = new T[mid];
        T[] right = new T[values.Length - mid];

        Array.Copy(values, 0, left, 0, mid);
        Array.Copy(values, mid, right, 0, values.Length - mid);

        left = DescendingSort(left);
        right = DescendingSort(right);

        return MergeDescending(left, right);
    }

    private T[] MergeAscending(T[] left, T[] right)
    {
        T[] result = new T[left.Length + right.Length];
        int i = 0, j = 0, k = 0;

        // ادغام دو بخش با مقایسه عناصر
        while (i < left.Length && j < right.Length)
        {
            if (left[i].CompareTo(right[j]) <= 0)
                result[k++] = left[i++];
            else
                result[k++] = right[j++];
        }

        // کپی عناصر باقی‌مانده از بخش چپ
        while (i < left.Length)
            result[k++] = left[i++];

        // کپی عناصر باقی‌مانده از بخش راست
        while (j < right.Length)
            result[k++] = right[j++];

        return result;
    }

    private T[] MergeDescending(T[] left, T[] right)
    {
        T[] result = new T[left.Length + right.Length];
        int i = 0, j = 0, k = 0;

        while (i < left.Length && j < right.Length)
        {
            if (left[i].CompareTo(right[j]) >= 0)
                result[k++] = left[i++];
            else
                result[k++] = right[j++];
        }

        while (i < left.Length)
            result[k++] = left[i++];

        while (j < right.Length)
            result[k++] = right[j++];

        return result;
    }
}

