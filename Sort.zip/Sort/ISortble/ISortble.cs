﻿namespace ISortable;

public interface ISortble<T> where T : IComparable<T>
{
    T[] AscendingSort(T[] values);
    
    T[] DescendingSort(T[] values);
}
