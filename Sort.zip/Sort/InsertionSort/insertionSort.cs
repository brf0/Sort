﻿
namespace InsertionSort;

public class insertionSort<T> : ISortable.ISortble<T> where T : IComparable<T>
{
    public T[] AscendingSort(T[] values)
    {
        for (int i = 1; i < values.Length; i++)
        {
            T key = values[i];
            int j = i - 1;

            while (j >= 0 && values[j].CompareTo(key) > 0) // مقایسه برای صعودی
            {
                values[j + 1] = values[j];
                j--;
            }
            values[j + 1] = key;
        }
        return values;
    }

    public T[] DescendingSort(T[] values)
    {
        for (int i = 1; i < values.Length; i++)
        {
            T key = values[i];
            int j = i - 1;

            while (j >= 0 && values[j].CompareTo(key) < 0) // مقایسه برای نزولی
            {
                values[j + 1] = values[j];
                j--;
            }
            values[j + 1] = key;
        }
        return values;
    }
}

