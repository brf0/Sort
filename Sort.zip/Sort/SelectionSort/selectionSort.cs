﻿
namespace SelectionSort;

public class selectionSort<T> : ISortable.ISortble<T> where T : IComparable<T>
{
    public T[] AscendingSort(T[] values)
    {
        for (int i = 0; i < values.Length - 1; i++)
        {
            int minIndex = i;
            for (int j = i + 1; j < values.Length; j++)
            {
                if (values[j].CompareTo(values[minIndex]) < 0) // مقایسه برای صعودی
                {
                    minIndex = j;
                }
            }
            (values[i], values[minIndex]) = (values[minIndex], values[i]); // جا‌به‌جایی
        }
        return values;
    }

    public T[] DescendingSort(T[] values)
    {
        for (int i = 0; i < values.Length - 1; i++)
        {
            int maxIndex = i;
            for (int j = i + 1; j < values.Length; j++)
            {
                if (values[j].CompareTo(values[maxIndex]) > 0) // مقایسه برای نزولی
                {
                    maxIndex = j;
                }
            }
            (values[i], values[maxIndex]) = (values[maxIndex], values[i]); // جا‌به‌جایی
        }
        return values;
    }
}
