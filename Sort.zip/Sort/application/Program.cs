﻿
using ISortable;


int[] array = { 22, 6, 14, 8, 2, 40 };


ISortable.ISortble<int> sortble = new MergeSort.MergSort<int>();

Console.WriteLine("Merge Sort Ascending: " + string.Join(", ", sortble.AscendingSort((int[])array.Clone())));
Console.WriteLine("Merge Sort Descending: " + string.Join(", ", sortble.DescendingSort((int[])array.Clone())));


//ISortable.ISortble<int> Sortble = new BubbleSort.bubbleSort<int>();

//Console.WriteLine("Bubble Sort Ascending: " + string.Join(", ", Sortble.AscendingSort((int[])array.Clone())));
//Console.WriteLine("Bubble Sort Descending: " + string.Join(", ", Sortble.DescendingSort((int[])array.Clone())));


//ISortable.ISortble<int> sortable = new SelectionSort.selectionSort<int>();

//Console.WriteLine("Selection Sort Ascending: " + string.Join(", ", sortable.AscendingSort((int[])array.Clone())));
//Console.WriteLine("Selection Sort Descending: " + string.Join(", ", sortable.DescendingSort((int[])array.Clone())));


//ISortable.ISortble<int> Sortable = new InsertionSort.insertionSort<int>();

//Console.WriteLine("Insertion Sort Ascending: " + string.Join(", ", Sortable.AscendingSort((int[])array.Clone())));
//Console.WriteLine("Insertion Sort Descending: " + string.Join(", ", Sortable.DescendingSort((int[])array.Clone())));



